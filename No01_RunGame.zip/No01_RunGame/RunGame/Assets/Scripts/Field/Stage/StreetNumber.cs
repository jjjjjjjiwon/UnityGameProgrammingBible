﻿public struct StreetNumber
{
	public int x;
	public int z;
	public StreetNumber(int x, int z)
	{
		this.x = x;
		this.z = z;
	}
}
